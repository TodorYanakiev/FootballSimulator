
-- --------------------------------------------------------

--
-- Table structure for table `line_up`
--
-- Creation: Apr 16, 2024 at 07:18 PM
-- Last update: Apr 16, 2024 at 07:35 PM
--

CREATE TABLE `line_up` (
  `id` bigint(20) NOT NULL,
  `football_formation` enum('FOUR_FOUR_TWO','FOUR_TWO_FOUR','FOUR_THREE_THREE','THREE_THREE_FOUR') DEFAULT NULL,
  `football_team_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `line_up`:
--   `football_team_id`
--       `football_team` -> `id`
--

--
-- Dumping data for table `line_up`
--

INSERT INTO `line_up` (`id`, `football_formation`, `football_team_id`) VALUES
(1, 'FOUR_THREE_THREE', 1),
(3, 'FOUR_THREE_THREE', 2),
(4, 'THREE_THREE_FOUR', 3),
(5, 'FOUR_TWO_FOUR', 4),
(7, 'FOUR_THREE_THREE', 5),
(9, 'FOUR_FOUR_TWO', 6);
