
-- --------------------------------------------------------

--
-- Table structure for table `base_football_team_seq`
--
-- Creation: Apr 05, 2024 at 08:07 AM
--

CREATE TABLE `base_football_team_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `base_football_team_seq`:
--

--
-- Dumping data for table `base_football_team_seq`
--

INSERT INTO `base_football_team_seq` (`next_val`) VALUES
(551);
