
-- --------------------------------------------------------

--
-- Table structure for table `user`
--
-- Creation: Apr 06, 2024 at 01:25 PM
-- Last update: Apr 16, 2024 at 07:35 PM
--

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT 1,
  `last_name` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('ROLE_ADMIN','ROLE_USER') DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `football_team_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `user`:
--   `football_team_id`
--       `football_team` -> `id`
--

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `enabled`, `last_name`, `name`, `password`, `role`, `username`, `football_team_id`) VALUES
(1, 'todor@todor', 1, 'Yanakiev', 'Todor', '$2a$10$9wbOQRq709RSRatui63QvOo8ScENSFxpdxsNi/cOzizDmCnWMwDse', 'ROLE_ADMIN', 'Toshko', NULL),
(1702, 'user1@user1', 1, 'user1', 'user1', '$2a$10$d/nTBMdIfIqOrI3yVe2Z5uficNvUIQ.ovc/N2E/JxE2ZQJdLygwOq', 'ROLE_USER', 'user1', 3);
