
-- --------------------------------------------------------

--
-- Table structure for table `football_match`
--
-- Creation: Apr 16, 2024 at 07:18 PM
-- Last update: Apr 16, 2024 at 07:36 PM
--

CREATE TABLE `football_match` (
  `id` bigint(20) NOT NULL,
  `away_attacks` tinyint(4) DEFAULT NULL,
  `away_shots` tinyint(4) DEFAULT NULL,
  `away_team_score` tinyint(4) DEFAULT NULL,
  `danger_away_attacks` tinyint(4) DEFAULT NULL,
  `danger_home_attacks` tinyint(4) DEFAULT NULL,
  `home_attacks` tinyint(4) DEFAULT NULL,
  `home_shots` tinyint(4) DEFAULT NULL,
  `home_team_score` tinyint(4) DEFAULT NULL,
  `match_status` enum('NOT_STARTED','STARTED','FINISHED') DEFAULT NULL,
  `away_team_id` bigint(20) DEFAULT NULL,
  `game_week_id` bigint(20) DEFAULT NULL,
  `home_team_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `football_match`:
--   `away_team_id`
--       `football_team` -> `id`
--   `game_week_id`
--       `game_week` -> `id`
--   `home_team_id`
--       `football_team` -> `id`
--

--
-- Dumping data for table `football_match`
--

INSERT INTO `football_match` (`id`, `away_attacks`, `away_shots`, `away_team_score`, `danger_away_attacks`, `danger_home_attacks`, `home_attacks`, `home_shots`, `home_team_score`, `match_status`, `away_team_id`, `game_week_id`, `home_team_id`) VALUES
(1, 34, 4, 0, 16, 37, 53, 16, 3, 'FINISHED', 1, 1, 6),
(2, 42, 12, 1, 25, 37, 44, 14, 0, 'FINISHED', 2, 1, 5),
(3, 32, 3, 1, 11, 28, 40, 6, 0, 'FINISHED', 3, 1, 4),
(4, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 6, 2, 2),
(5, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 1, 2, 3),
(6, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 5, 2, 4),
(7, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 3, 3, 6),
(8, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 4, 3, 2),
(9, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 5, 3, 1),
(10, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 6, 4, 4),
(11, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 3, 4, 5),
(12, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 2, 4, 1),
(13, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 5, 5, 6),
(14, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 1, 5, 4),
(15, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 2, 5, 3),
(16, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 6, 6, 1),
(17, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 5, 6, 2),
(18, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 4, 6, 3),
(19, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 2, 7, 6),
(20, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 3, 7, 1),
(21, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 4, 7, 5),
(22, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 6, 8, 3),
(23, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 2, 8, 4),
(24, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 1, 8, 5),
(25, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 4, 9, 6),
(26, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 5, 9, 3),
(27, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 1, 9, 2),
(28, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 6, 10, 5),
(29, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 4, 10, 1),
(30, 0, 0, 0, 0, 0, 0, 0, 0, 'NOT_STARTED', 3, 10, 2);
