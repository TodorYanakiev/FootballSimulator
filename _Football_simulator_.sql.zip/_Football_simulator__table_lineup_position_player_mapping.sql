
-- --------------------------------------------------------

--
-- Table structure for table `lineup_position_player_mapping`
--
-- Creation: Apr 16, 2024 at 07:18 PM
-- Last update: Apr 16, 2024 at 07:36 PM
--

CREATE TABLE `lineup_position_player_mapping` (
  `line_up_id` bigint(20) NOT NULL,
  `position_football_player_map_id` bigint(20) NOT NULL,
  `position` enum('GK','LB','LCB','CB','RCB','RB','LM','LCM','CM','RCM','RM','RF','LCF','CF','RCF','LF') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `lineup_position_player_mapping`:
--   `line_up_id`
--       `line_up` -> `id`
--   `position_football_player_map_id`
--       `football_player` -> `id`
--

--
-- Dumping data for table `lineup_position_player_mapping`
--

INSERT INTO `lineup_position_player_mapping` (`line_up_id`, `position_football_player_map_id`, `position`) VALUES
(1, 1, 'GK'),
(1, 2, 'LB'),
(1, 3, 'LCB'),
(1, 5, 'RCB'),
(1, 6, 'RB'),
(1, 7, 'CM'),
(1, 8, 'LCM'),
(1, 9, 'CF'),
(1, 10, 'RF'),
(1, 11, 'LF'),
(1, 12, 'RCM'),
(3, 18, 'LCB'),
(3, 20, 'LB'),
(3, 25, 'LF'),
(3, 26, 'CF'),
(3, 28, 'RF'),
(3, 29, 'CM'),
(3, 30, 'RCM'),
(3, 31, 'RCB'),
(3, 32, 'GK'),
(3, 35, 'LCM'),
(3, 37, 'RB'),
(4, 39, 'LF'),
(4, 40, 'CM'),
(4, 41, 'RF'),
(4, 42, 'LCF'),
(4, 45, 'LCM'),
(4, 46, 'RCM'),
(4, 49, 'LCB'),
(4, 50, 'CB'),
(4, 51, 'RCB'),
(4, 53, 'RCF'),
(4, 57, 'GK'),
(5, 58, 'LB'),
(5, 59, 'RCM'),
(5, 61, 'LCM'),
(5, 63, 'LCB'),
(5, 64, 'RB'),
(5, 65, 'RCB'),
(5, 67, 'GK'),
(5, 68, 'LCF'),
(5, 69, 'RCF'),
(5, 70, 'RF'),
(5, 73, 'LF'),
(7, 75, 'LCM'),
(7, 78, 'RCB'),
(7, 79, 'LB'),
(7, 82, 'LCB'),
(7, 83, 'GK'),
(7, 84, 'RB'),
(7, 85, 'CF'),
(7, 86, 'RF'),
(7, 87, 'CM'),
(7, 89, 'RCM'),
(7, 90, 'LF'),
(9, 143, 'LB'),
(9, 144, 'RCB'),
(9, 146, 'LCB'),
(9, 147, 'RB'),
(9, 148, 'GK'),
(9, 150, 'LCM'),
(9, 151, 'RCF'),
(9, 152, 'LCF'),
(9, 153, 'RCM'),
(9, 154, 'LM'),
(9, 155, 'RM');
