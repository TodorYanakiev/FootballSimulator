
-- --------------------------------------------------------

--
-- Table structure for table `user_seq`
--
-- Creation: Apr 05, 2024 at 08:07 AM
-- Last update: Apr 16, 2024 at 07:35 PM
--

CREATE TABLE `user_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `user_seq`:
--

--
-- Dumping data for table `user_seq`
--

INSERT INTO `user_seq` (`next_val`) VALUES
(1801);
