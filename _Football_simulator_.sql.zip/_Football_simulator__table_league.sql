
-- --------------------------------------------------------

--
-- Table structure for table `league`
--
-- Creation: Apr 16, 2024 at 07:18 PM
-- Last update: Apr 16, 2024 at 07:35 PM
--

CREATE TABLE `league` (
  `id` bigint(20) NOT NULL,
  `league_status` enum('NOT_STARTED','STARTED','FINISHED') DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `league`:
--

--
-- Dumping data for table `league`
--

INSERT INTO `league` (`id`, `league_status`, `name`) VALUES
(1, 'STARTED', 'Premier League');
