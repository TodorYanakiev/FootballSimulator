
-- --------------------------------------------------------

--
-- Table structure for table `game_week`
--
-- Creation: Apr 16, 2024 at 07:18 PM
-- Last update: Apr 16, 2024 at 07:35 PM
--

CREATE TABLE `game_week` (
  `id` bigint(20) NOT NULL,
  `game_week_status` enum('NOT_STARTED','STARTED','FINISHED') DEFAULT NULL,
  `week_number` tinyint(4) DEFAULT NULL,
  `league_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `game_week`:
--   `league_id`
--       `league` -> `id`
--

--
-- Dumping data for table `game_week`
--

INSERT INTO `game_week` (`id`, `game_week_status`, `week_number`, `league_id`) VALUES
(1, 'FINISHED', 1, 1),
(2, 'NOT_STARTED', 2, 1),
(3, 'NOT_STARTED', 3, 1),
(4, 'NOT_STARTED', 4, 1),
(5, 'NOT_STARTED', 5, 1),
(6, 'NOT_STARTED', 6, 1),
(7, 'NOT_STARTED', 7, 1),
(8, 'NOT_STARTED', 8, 1),
(9, 'NOT_STARTED', 9, 1),
(10, 'NOT_STARTED', 10, 1);
