
-- --------------------------------------------------------

--
-- Table structure for table `football_team_seq`
--
-- Creation: Apr 16, 2024 at 07:18 PM
-- Last update: Apr 16, 2024 at 07:20 PM
--

CREATE TABLE `football_team_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `football_team_seq`:
--

--
-- Dumping data for table `football_team_seq`
--

INSERT INTO `football_team_seq` (`next_val`) VALUES
(101);
