
--
-- Indexes for dumped tables
--

--
-- Indexes for table `base_football_player`
--
ALTER TABLE `base_football_player`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `base_football_team`
--
ALTER TABLE `base_football_team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `football_match`
--
ALTER TABLE `football_match`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKbbfml1f89d4kly41d5g4bv8t8` (`away_team_id`),
  ADD KEY `FKfo7ypt4ek9xvn1tugp2bhf5k6` (`game_week_id`),
  ADD KEY `FKoom11g5lkhhsv32xxca5xkn4f` (`home_team_id`);

--
-- Indexes for table `football_player`
--
ALTER TABLE `football_player`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKo6a6rfp0yccpugu27xh06dfht` (`base_player_id`),
  ADD KEY `FK49o3datpimqs0ax8ydqijtxt8` (`football_team_id`);

--
-- Indexes for table `football_team`
--
ALTER TABLE `football_team`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKn4osoqkwbwkge8q4bb2b8lvpu` (`base_football_team_id`),
  ADD KEY `FKtrqeenkyjomup0m2i3bevgcij` (`league_id`);

--
-- Indexes for table `game_week`
--
ALTER TABLE `game_week`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKhqx0ex5sepd10u7lflwalv6b5` (`league_id`);

--
-- Indexes for table `league`
--
ALTER TABLE `league`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lineup_position_player_mapping`
--
ALTER TABLE `lineup_position_player_mapping`
  ADD PRIMARY KEY (`line_up_id`,`position`),
  ADD UNIQUE KEY `UK_7ifrnnmbyvodym2aub8xy3vek` (`position_football_player_map_id`);

--
-- Indexes for table `line_up`
--
ALTER TABLE `line_up`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_1de5ji9jxvoishegdfvs8n7uo` (`football_team_id`);

--
-- Indexes for table `standing`
--
ALTER TABLE `standing`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_loiy2q4rxubo93gm04hmlfnml` (`football_team_id`),
  ADD KEY `FKjcc3ij6u5ud5ah9ersu4e18lb` (`league_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_lhab2eet43seyv9qmpgq93ckm` (`football_team_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `football_match`
--
ALTER TABLE `football_match`
  ADD CONSTRAINT `FKbbfml1f89d4kly41d5g4bv8t8` FOREIGN KEY (`away_team_id`) REFERENCES `football_team` (`id`),
  ADD CONSTRAINT `FKfo7ypt4ek9xvn1tugp2bhf5k6` FOREIGN KEY (`game_week_id`) REFERENCES `game_week` (`id`),
  ADD CONSTRAINT `FKoom11g5lkhhsv32xxca5xkn4f` FOREIGN KEY (`home_team_id`) REFERENCES `football_team` (`id`);

--
-- Constraints for table `football_player`
--
ALTER TABLE `football_player`
  ADD CONSTRAINT `FK49o3datpimqs0ax8ydqijtxt8` FOREIGN KEY (`football_team_id`) REFERENCES `football_team` (`id`),
  ADD CONSTRAINT `FKo6a6rfp0yccpugu27xh06dfht` FOREIGN KEY (`base_player_id`) REFERENCES `base_football_player` (`id`);

--
-- Constraints for table `football_team`
--
ALTER TABLE `football_team`
  ADD CONSTRAINT `FKn4osoqkwbwkge8q4bb2b8lvpu` FOREIGN KEY (`base_football_team_id`) REFERENCES `base_football_team` (`id`),
  ADD CONSTRAINT `FKtrqeenkyjomup0m2i3bevgcij` FOREIGN KEY (`league_id`) REFERENCES `league` (`id`);

--
-- Constraints for table `game_week`
--
ALTER TABLE `game_week`
  ADD CONSTRAINT `FKhqx0ex5sepd10u7lflwalv6b5` FOREIGN KEY (`league_id`) REFERENCES `league` (`id`);

--
-- Constraints for table `lineup_position_player_mapping`
--
ALTER TABLE `lineup_position_player_mapping`
  ADD CONSTRAINT `FKesvl8r3ggxejs9w0b97r9atlq` FOREIGN KEY (`line_up_id`) REFERENCES `line_up` (`id`),
  ADD CONSTRAINT `FKo6xaoo1jsum0behgb0ilkteab` FOREIGN KEY (`position_football_player_map_id`) REFERENCES `football_player` (`id`);

--
-- Constraints for table `line_up`
--
ALTER TABLE `line_up`
  ADD CONSTRAINT `FKb3txptcvhhs3bor7nh8ujo8cu` FOREIGN KEY (`football_team_id`) REFERENCES `football_team` (`id`);

--
-- Constraints for table `standing`
--
ALTER TABLE `standing`
  ADD CONSTRAINT `FKcq526b8e6jts4fcfcqqu2kwob` FOREIGN KEY (`football_team_id`) REFERENCES `football_team` (`id`),
  ADD CONSTRAINT `FKjcc3ij6u5ud5ah9ersu4e18lb` FOREIGN KEY (`league_id`) REFERENCES `league` (`id`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `FK9h43okg9bw4b45m456wdmknxj` FOREIGN KEY (`football_team_id`) REFERENCES `football_team` (`id`);
