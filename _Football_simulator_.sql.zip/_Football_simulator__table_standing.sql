
-- --------------------------------------------------------

--
-- Table structure for table `standing`
--
-- Creation: Apr 16, 2024 at 07:18 PM
-- Last update: Apr 16, 2024 at 07:36 PM
--

CREATE TABLE `standing` (
  `id` bigint(20) NOT NULL,
  `conceded_goals` smallint(6) DEFAULT NULL,
  `played_matches` tinyint(4) DEFAULT NULL,
  `points` tinyint(4) DEFAULT NULL,
  `scored_goals` smallint(6) DEFAULT NULL,
  `football_team_id` bigint(20) DEFAULT NULL,
  `league_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `standing`:
--   `football_team_id`
--       `football_team` -> `id`
--   `league_id`
--       `league` -> `id`
--

--
-- Dumping data for table `standing`
--

INSERT INTO `standing` (`id`, `conceded_goals`, `played_matches`, `points`, `scored_goals`, `football_team_id`, `league_id`) VALUES
(1, 3, 1, 0, 0, 1, 1),
(2, 0, 1, 3, 1, 2, 1),
(3, 0, 1, 3, 1, 3, 1),
(4, 1, 1, 0, 0, 4, 1),
(5, 1, 1, 0, 0, 5, 1),
(6, 0, 1, 3, 3, 6, 1);
