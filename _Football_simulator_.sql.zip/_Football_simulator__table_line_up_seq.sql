
-- --------------------------------------------------------

--
-- Table structure for table `line_up_seq`
--
-- Creation: Apr 16, 2024 at 07:18 PM
-- Last update: Apr 16, 2024 at 07:23 PM
--

CREATE TABLE `line_up_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `line_up_seq`:
--

--
-- Dumping data for table `line_up_seq`
--

INSERT INTO `line_up_seq` (`next_val`) VALUES
(101);
