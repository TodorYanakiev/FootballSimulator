
-- --------------------------------------------------------

--
-- Table structure for table `base_football_team`
--
-- Creation: Apr 06, 2024 at 09:30 AM
--

CREATE TABLE `base_football_team` (
  `id` bigint(20) NOT NULL,
  `abbreviation` varchar(4) DEFAULT NULL,
  `base_team_name` varchar(255) DEFAULT NULL,
  `stadium_name` varchar(255) DEFAULT NULL,
  `start_budged` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `base_football_team`:
--

--
-- Dumping data for table `base_football_team`
--

INSERT INTO `base_football_team` (`id`, `abbreviation`, `base_team_name`, `stadium_name`, `start_budged`, `name`) VALUES
(1, 'TRZ', 'Torpedo Razgrad', 'TorpedoArena', 60000000, NULL),
(2, 'BOT', 'Botev Vratsa', 'Hristo Botev', 76000000, NULL),
(3, 'RMD', 'Real Madrid', 'Santiago Bernabeu', 80000000, NULL),
(4, 'CHE', 'Chelsea', 'Stamford Bridge', 100000000, NULL),
(5, 'CSKA', 'CSKA-Sofia', 'Bulgarska armiya ', 32000000, NULL),
(6, 'BAY', 'Bayer Leverkusen', 'Bayarena', 55000000, NULL),
(52, 'LEI', 'LeicesterCity', 'Leicester arena', 50000000, NULL),
(102, 'JUV', 'Juventus', 'Allianz Stadium', 67000000, NULL),
(103, 'ARS', 'Arsenal', 'Emirates Stadium', 80000000, NULL),
(104, 'ATM', 'Atletico Madrid', 'Metropolitan Stadium', 68500000, NULL),
(152, 'LGO', 'Lokomotiv Gorna Oryahovica', 'Loko arena', 70000000, NULL),
(202, 'CHE', 'Chernomorets', 'Chernomorets Arena', 80000000, NULL),
(252, 'SLA', 'Slavia Sofia', 'Arena Slavia ', 80000000, NULL),
(302, 'HEB', 'Hebar Pazardzhik', 'Arena Hebar', 50000000, NULL),
(352, 'CSKA', 'CSKA 1948', 'cska arena', 80000000, NULL),
(402, 'LK', 'Levski Krivnya', 'LKR', 100000000, NULL),
(452, 'TPO', 'Tornado Poroishte', 'Polyana Poroishte ', 90000000, NULL);
