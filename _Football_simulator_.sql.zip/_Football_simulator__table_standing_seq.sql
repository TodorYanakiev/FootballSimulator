
-- --------------------------------------------------------

--
-- Table structure for table `standing_seq`
--
-- Creation: Apr 16, 2024 at 07:18 PM
-- Last update: Apr 16, 2024 at 07:35 PM
--

CREATE TABLE `standing_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `standing_seq`:
--

--
-- Dumping data for table `standing_seq`
--

INSERT INTO `standing_seq` (`next_val`) VALUES
(101);
