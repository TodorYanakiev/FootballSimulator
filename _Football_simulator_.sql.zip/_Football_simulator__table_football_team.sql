
-- --------------------------------------------------------

--
-- Table structure for table `football_team`
--
-- Creation: Apr 16, 2024 at 07:18 PM
-- Last update: Apr 16, 2024 at 07:36 PM
--

CREATE TABLE `football_team` (
  `id` bigint(20) NOT NULL,
  `budged` int(11) DEFAULT NULL,
  `base_football_team_id` bigint(20) DEFAULT NULL,
  `league_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `football_team`:
--   `base_football_team_id`
--       `base_football_team` -> `id`
--   `league_id`
--       `league` -> `id`
--

--
-- Dumping data for table `football_team`
--

INSERT INTO `football_team` (`id`, `budged`, `base_football_team_id`, `league_id`) VALUES
(1, 62500000, 1, 1),
(2, 86000000, 2, 1),
(3, 90000000, 3, 1),
(4, 57500000, 6, 1),
(5, 52500000, 52, 1),
(6, 77000000, 102, 1);
